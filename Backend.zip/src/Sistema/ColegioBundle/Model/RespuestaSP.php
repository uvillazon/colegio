<?php
/**
 * Created by PhpStorm.
 * User: uvillazon
 * Date: 16/07/2015
 * Time: 03:06 PM
 */

namespace Sistema\ColegioBundle\Model;


class RespuestaSP
{
    public $success;
    public $msg;
    public $id;
    public $data;
}